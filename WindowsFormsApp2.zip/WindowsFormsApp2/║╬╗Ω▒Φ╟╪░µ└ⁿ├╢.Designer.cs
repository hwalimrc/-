﻿namespace WindowsFormsApp2
{
    partial class 부산김해경전철
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(부산김해경전철));
            this.panel1 = new System.Windows.Forms.Panel();
            this.가야대 = new System.Windows.Forms.RadioButton();
            this.박물관 = new System.Windows.Forms.RadioButton();
            this.수로왕릉 = new System.Windows.Forms.RadioButton();
            this.인제대 = new System.Windows.Forms.RadioButton();
            this.대저 = new System.Windows.Forms.RadioButton();
            this.김해공항 = new System.Windows.Forms.RadioButton();
            this.궤법르네시떼 = new System.Windows.Forms.RadioButton();
            this.사상 = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::WindowsFormsApp2.Properties.Resources.부산김해경전철;
            this.panel1.Controls.Add(this.가야대);
            this.panel1.Controls.Add(this.박물관);
            this.panel1.Controls.Add(this.수로왕릉);
            this.panel1.Controls.Add(this.인제대);
            this.panel1.Controls.Add(this.대저);
            this.panel1.Controls.Add(this.김해공항);
            this.panel1.Controls.Add(this.궤법르네시떼);
            this.panel1.Controls.Add(this.사상);
            this.panel1.Location = new System.Drawing.Point(13, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(764, 223);
            this.panel1.TabIndex = 0;
            // 
            // 가야대
            // 
            this.가야대.AutoSize = true;
            this.가야대.Location = new System.Drawing.Point(148, 23);
            this.가야대.Name = "가야대";
            this.가야대.Size = new System.Drawing.Size(14, 13);
            this.가야대.TabIndex = 7;
            this.가야대.TabStop = true;
            this.가야대.UseVisualStyleBackColor = true;
            this.가야대.CheckedChanged += new System.EventHandler(this.가야대_CheckedChanged);
            // 
            // 박물관
            // 
            this.박물관.AutoSize = true;
            this.박물관.Location = new System.Drawing.Point(413, 23);
            this.박물관.Name = "박물관";
            this.박물관.Size = new System.Drawing.Size(14, 13);
            this.박물관.TabIndex = 6;
            this.박물관.TabStop = true;
            this.박물관.UseVisualStyleBackColor = true;
            this.박물관.CheckedChanged += new System.EventHandler(this.박물관_CheckedChanged);
            // 
            // 수로왕릉
            // 
            this.수로왕릉.AutoSize = true;
            this.수로왕릉.Location = new System.Drawing.Point(484, 23);
            this.수로왕릉.Name = "수로왕릉";
            this.수로왕릉.Size = new System.Drawing.Size(14, 13);
            this.수로왕릉.TabIndex = 5;
            this.수로왕릉.TabStop = true;
            this.수로왕릉.UseVisualStyleBackColor = true;
            this.수로왕릉.CheckedChanged += new System.EventHandler(this.수로왕릉_CheckedChanged);
            // 
            // 인제대
            // 
            this.인제대.AutoSize = true;
            this.인제대.Location = new System.Drawing.Point(745, 62);
            this.인제대.Name = "인제대";
            this.인제대.Size = new System.Drawing.Size(14, 13);
            this.인제대.TabIndex = 4;
            this.인제대.TabStop = true;
            this.인제대.UseVisualStyleBackColor = true;
            this.인제대.CheckedChanged += new System.EventHandler(this.인제대_CheckedChanged);
            // 
            // 대저
            // 
            this.대저.AutoSize = true;
            this.대저.Location = new System.Drawing.Point(552, 202);
            this.대저.Name = "대저";
            this.대저.Size = new System.Drawing.Size(14, 13);
            this.대저.TabIndex = 3;
            this.대저.TabStop = true;
            this.대저.UseVisualStyleBackColor = true;
            this.대저.CheckedChanged += new System.EventHandler(this.대저_CheckedChanged);
            // 
            // 김해공항
            // 
            this.김해공항.AutoSize = true;
            this.김해공항.Location = new System.Drawing.Point(406, 202);
            this.김해공항.Name = "김해공항";
            this.김해공항.Size = new System.Drawing.Size(14, 13);
            this.김해공항.TabIndex = 2;
            this.김해공항.TabStop = true;
            this.김해공항.UseVisualStyleBackColor = true;
            this.김해공항.CheckedChanged += new System.EventHandler(this.김해공항_CheckedChanged);
            // 
            // 궤법르네시떼
            // 
            this.궤법르네시떼.AutoSize = true;
            this.궤법르네시떼.Location = new System.Drawing.Point(247, 202);
            this.궤법르네시떼.Name = "궤법르네시떼";
            this.궤법르네시떼.Size = new System.Drawing.Size(14, 13);
            this.궤법르네시떼.TabIndex = 1;
            this.궤법르네시떼.TabStop = true;
            this.궤법르네시떼.UseVisualStyleBackColor = true;
            this.궤법르네시떼.CheckedChanged += new System.EventHandler(this.궤법르네시떼_CheckedChanged);
            // 
            // 사상
            // 
            this.사상.AutoSize = true;
            this.사상.Location = new System.Drawing.Point(181, 202);
            this.사상.Name = "사상";
            this.사상.Size = new System.Drawing.Size(14, 13);
            this.사상.TabIndex = 0;
            this.사상.TabStop = true;
            this.사상.UseVisualStyleBackColor = true;
            this.사상.CheckedChanged += new System.EventHandler(this.사상_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(596, 295);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(181, 30);
            this.button2.TabIndex = 12;
            this.button2.Text = "도착역으로 지정";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(409, 295);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 30);
            this.button1.TabIndex = 11;
            this.button1.Text = "출발역으로 지정";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(280, 255);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 21);
            this.textBox1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(12, 252);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "역 이름을 선택하세요:";
            // 
            // 부산김해경전철
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 338);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "부산김해경전철";
            this.Text = "부산김해경전철";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton 김해공항;
        private System.Windows.Forms.RadioButton 궤법르네시떼;
        private System.Windows.Forms.RadioButton 사상;
        private System.Windows.Forms.RadioButton 가야대;
        private System.Windows.Forms.RadioButton 박물관;
        private System.Windows.Forms.RadioButton 수로왕릉;
        private System.Windows.Forms.RadioButton 인제대;
        private System.Windows.Forms.RadioButton 대저;
    }
}