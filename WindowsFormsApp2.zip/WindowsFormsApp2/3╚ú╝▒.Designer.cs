﻿namespace WindowsFormsApp2
{
    partial class _3호선
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(_3호선));
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.대저 = new System.Windows.Forms.RadioButton();
            this.강서구청 = new System.Windows.Forms.RadioButton();
            this.구포 = new System.Windows.Forms.RadioButton();
            this.덕천 = new System.Windows.Forms.RadioButton();
            this.숙동 = new System.Windows.Forms.RadioButton();
            this.만덕 = new System.Windows.Forms.RadioButton();
            this.미남 = new System.Windows.Forms.RadioButton();
            this.사직 = new System.Windows.Forms.RadioButton();
            this.종합운동장 = new System.Windows.Forms.RadioButton();
            this.거제 = new System.Windows.Forms.RadioButton();
            this.연산 = new System.Windows.Forms.RadioButton();
            this.망미 = new System.Windows.Forms.RadioButton();
            this.수영 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(543, 296);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(181, 30);
            this.button2.TabIndex = 12;
            this.button2.Text = "도착역으로 지정";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(345, 296);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 30);
            this.button1.TabIndex = 11;
            this.button1.Text = "출발역으로 지정";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(279, 241);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 21);
            this.textBox1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(7, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "역 이름을 선택하세요:";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::WindowsFormsApp2.Properties.Resources._3호선;
            this.panel1.Controls.Add(this.대저);
            this.panel1.Controls.Add(this.강서구청);
            this.panel1.Controls.Add(this.구포);
            this.panel1.Controls.Add(this.덕천);
            this.panel1.Controls.Add(this.숙동);
            this.panel1.Controls.Add(this.만덕);
            this.panel1.Controls.Add(this.미남);
            this.panel1.Controls.Add(this.사직);
            this.panel1.Controls.Add(this.종합운동장);
            this.panel1.Controls.Add(this.거제);
            this.panel1.Controls.Add(this.연산);
            this.panel1.Controls.Add(this.망미);
            this.panel1.Controls.Add(this.수영);
            this.panel1.Location = new System.Drawing.Point(11, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(713, 216);
            this.panel1.TabIndex = 0;
            // 
            // 대저
            // 
            this.대저.AutoSize = true;
            this.대저.Location = new System.Drawing.Point(680, 131);
            this.대저.Name = "대저";
            this.대저.Size = new System.Drawing.Size(14, 13);
            this.대저.TabIndex = 16;
            this.대저.TabStop = true;
            this.대저.UseVisualStyleBackColor = true;
            this.대저.CheckedChanged += new System.EventHandler(this.대저_CheckedChanged);
            // 
            // 강서구청
            // 
            this.강서구청.AutoSize = true;
            this.강서구청.Location = new System.Drawing.Point(597, 129);
            this.강서구청.Name = "강서구청";
            this.강서구청.Size = new System.Drawing.Size(14, 13);
            this.강서구청.TabIndex = 14;
            this.강서구청.TabStop = true;
            this.강서구청.UseVisualStyleBackColor = true;
            this.강서구청.CheckedChanged += new System.EventHandler(this.강서구청_CheckedChanged);
            // 
            // 구포
            // 
            this.구포.AutoSize = true;
            this.구포.Location = new System.Drawing.Point(554, 130);
            this.구포.Name = "구포";
            this.구포.Size = new System.Drawing.Size(14, 13);
            this.구포.TabIndex = 13;
            this.구포.TabStop = true;
            this.구포.UseVisualStyleBackColor = true;
            this.구포.CheckedChanged += new System.EventHandler(this.구포_CheckedChanged);
            // 
            // 덕천
            // 
            this.덕천.AutoSize = true;
            this.덕천.Location = new System.Drawing.Point(513, 129);
            this.덕천.Name = "덕천";
            this.덕천.Size = new System.Drawing.Size(14, 13);
            this.덕천.TabIndex = 12;
            this.덕천.TabStop = true;
            this.덕천.UseVisualStyleBackColor = true;
            this.덕천.CheckedChanged += new System.EventHandler(this.덕천_CheckedChanged);
            // 
            // 숙동
            // 
            this.숙동.AutoSize = true;
            this.숙동.Location = new System.Drawing.Point(472, 130);
            this.숙동.Name = "숙동";
            this.숙동.Size = new System.Drawing.Size(14, 13);
            this.숙동.TabIndex = 11;
            this.숙동.TabStop = true;
            this.숙동.UseVisualStyleBackColor = true;
            this.숙동.CheckedChanged += new System.EventHandler(this.숙동_CheckedChanged);
            // 
            // 만덕
            // 
            this.만덕.AutoSize = true;
            this.만덕.Location = new System.Drawing.Point(388, 130);
            this.만덕.Name = "만덕";
            this.만덕.Size = new System.Drawing.Size(14, 13);
            this.만덕.TabIndex = 9;
            this.만덕.TabStop = true;
            this.만덕.UseVisualStyleBackColor = true;
            this.만덕.CheckedChanged += new System.EventHandler(this.만덕_CheckedChanged);
            // 
            // 미남
            // 
            this.미남.AutoSize = true;
            this.미남.Location = new System.Drawing.Point(349, 129);
            this.미남.Name = "미남";
            this.미남.Size = new System.Drawing.Size(14, 13);
            this.미남.TabIndex = 8;
            this.미남.TabStop = true;
            this.미남.UseVisualStyleBackColor = true;
            this.미남.CheckedChanged += new System.EventHandler(this.미남_CheckedChanged);
            // 
            // 사직
            // 
            this.사직.AutoSize = true;
            this.사직.Location = new System.Drawing.Point(307, 130);
            this.사직.Name = "사직";
            this.사직.Size = new System.Drawing.Size(14, 13);
            this.사직.TabIndex = 7;
            this.사직.TabStop = true;
            this.사직.UseVisualStyleBackColor = true;
            this.사직.CheckedChanged += new System.EventHandler(this.사직_CheckedChanged);
            // 
            // 종합운동장
            // 
            this.종합운동장.AutoSize = true;
            this.종합운동장.Location = new System.Drawing.Point(262, 130);
            this.종합운동장.Name = "종합운동장";
            this.종합운동장.Size = new System.Drawing.Size(14, 13);
            this.종합운동장.TabIndex = 6;
            this.종합운동장.TabStop = true;
            this.종합운동장.UseVisualStyleBackColor = true;
            this.종합운동장.CheckedChanged += new System.EventHandler(this.종합운동장_CheckedChanged);
            // 
            // 거제
            // 
            this.거제.AutoSize = true;
            this.거제.Location = new System.Drawing.Point(224, 130);
            this.거제.Name = "거제";
            this.거제.Size = new System.Drawing.Size(14, 13);
            this.거제.TabIndex = 5;
            this.거제.TabStop = true;
            this.거제.UseVisualStyleBackColor = true;
            this.거제.CheckedChanged += new System.EventHandler(this.거제_CheckedChanged);
            // 
            // 연산
            // 
            this.연산.AutoSize = true;
            this.연산.Location = new System.Drawing.Point(182, 130);
            this.연산.Name = "연산";
            this.연산.Size = new System.Drawing.Size(14, 13);
            this.연산.TabIndex = 4;
            this.연산.TabStop = true;
            this.연산.UseVisualStyleBackColor = true;
            this.연산.CheckedChanged += new System.EventHandler(this.연산_CheckedChanged);
            // 
            // 망미
            // 
            this.망미.AutoSize = true;
            this.망미.Location = new System.Drawing.Point(57, 130);
            this.망미.Name = "망미";
            this.망미.Size = new System.Drawing.Size(14, 13);
            this.망미.TabIndex = 1;
            this.망미.TabStop = true;
            this.망미.UseVisualStyleBackColor = true;
            this.망미.CheckedChanged += new System.EventHandler(this.망미_CheckedChanged);
            // 
            // 수영
            // 
            this.수영.AutoSize = true;
            this.수영.Location = new System.Drawing.Point(16, 130);
            this.수영.Name = "수영";
            this.수영.Size = new System.Drawing.Size(14, 13);
            this.수영.TabIndex = 0;
            this.수영.TabStop = true;
            this.수영.UseVisualStyleBackColor = true;
            this.수영.CheckedChanged += new System.EventHandler(this.수영_CheckedChanged);
            // 
            // _3호선
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 332);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "_3호선";
            this.Text = "_3호선";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton 망미;
        private System.Windows.Forms.RadioButton 수영;
        private System.Windows.Forms.RadioButton 대저;
        private System.Windows.Forms.RadioButton 강서구청;
        private System.Windows.Forms.RadioButton 구포;
        private System.Windows.Forms.RadioButton 덕천;
        private System.Windows.Forms.RadioButton 숙동;
        private System.Windows.Forms.RadioButton 만덕;
        private System.Windows.Forms.RadioButton 미남;
        private System.Windows.Forms.RadioButton 사직;
        private System.Windows.Forms.RadioButton 종합운동장;
        private System.Windows.Forms.RadioButton 거제;
        private System.Windows.Forms.RadioButton 연산;
    }
}