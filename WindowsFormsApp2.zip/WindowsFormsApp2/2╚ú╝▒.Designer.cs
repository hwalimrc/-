﻿namespace WindowsFormsApp2
{
    partial class _2호선
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(_2호선));
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.양산 = new System.Windows.Forms.RadioButton();
            this.부산대양산 = new System.Windows.Forms.RadioButton();
            this.덕천 = new System.Windows.Forms.RadioButton();
            this.사상 = new System.Windows.Forms.RadioButton();
            this.감천 = new System.Windows.Forms.RadioButton();
            this.동의대 = new System.Windows.Forms.RadioButton();
            this.서면 = new System.Windows.Forms.RadioButton();
            this.부산은행 = new System.Windows.Forms.RadioButton();
            this.경성대 = new System.Windows.Forms.RadioButton();
            this.광안 = new System.Windows.Forms.RadioButton();
            this.수영 = new System.Windows.Forms.RadioButton();
            this.센텀시티 = new System.Windows.Forms.RadioButton();
            this.시립미술관 = new System.Windows.Forms.RadioButton();
            this.해운대 = new System.Windows.Forms.RadioButton();
            this.장산 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(635, 324);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(181, 30);
            this.button2.TabIndex = 8;
            this.button2.Text = "도착역으로 지정";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(433, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 30);
            this.button1.TabIndex = 7;
            this.button1.Text = "출발역으로 지정";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(280, 269);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 21);
            this.textBox1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(12, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "역 이름을 선택하세요:";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::WindowsFormsApp2.Properties.Resources._2호선;
            this.panel1.Controls.Add(this.양산);
            this.panel1.Controls.Add(this.부산대양산);
            this.panel1.Controls.Add(this.덕천);
            this.panel1.Controls.Add(this.사상);
            this.panel1.Controls.Add(this.감천);
            this.panel1.Controls.Add(this.동의대);
            this.panel1.Controls.Add(this.서면);
            this.panel1.Controls.Add(this.부산은행);
            this.panel1.Controls.Add(this.경성대);
            this.panel1.Controls.Add(this.광안);
            this.panel1.Controls.Add(this.수영);
            this.panel1.Controls.Add(this.센텀시티);
            this.panel1.Controls.Add(this.시립미술관);
            this.panel1.Controls.Add(this.해운대);
            this.panel1.Controls.Add(this.장산);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 243);
            this.panel1.TabIndex = 0;
            // 
            // 양산
            // 
            this.양산.AutoSize = true;
            this.양산.Location = new System.Drawing.Point(773, 142);
            this.양산.Name = "양산";
            this.양산.Size = new System.Drawing.Size(14, 13);
            this.양산.TabIndex = 17;
            this.양산.TabStop = true;
            this.양산.UseVisualStyleBackColor = true;
            this.양산.CheckedChanged += new System.EventHandler(this.양산_CheckedChanged);
            // 
            // 부산대양산
            // 
            this.부산대양산.AutoSize = true;
            this.부산대양산.Location = new System.Drawing.Point(738, 142);
            this.부산대양산.Name = "부산대양산";
            this.부산대양산.Size = new System.Drawing.Size(14, 13);
            this.부산대양산.TabIndex = 16;
            this.부산대양산.TabStop = true;
            this.부산대양산.UseVisualStyleBackColor = true;
            this.부산대양산.CheckedChanged += new System.EventHandler(this.부산대양산_CheckedChanged);
            // 
            // 덕천
            // 
            this.덕천.AutoSize = true;
            this.덕천.Location = new System.Drawing.Point(592, 142);
            this.덕천.Name = "덕천";
            this.덕천.Size = new System.Drawing.Size(14, 13);
            this.덕천.TabIndex = 13;
            this.덕천.TabStop = true;
            this.덕천.UseVisualStyleBackColor = true;
            this.덕천.CheckedChanged += new System.EventHandler(this.덕천_CheckedChanged);
            // 
            // 사상
            // 
            this.사상.AutoSize = true;
            this.사상.Location = new System.Drawing.Point(484, 142);
            this.사상.Name = "사상";
            this.사상.Size = new System.Drawing.Size(14, 13);
            this.사상.TabIndex = 11;
            this.사상.TabStop = true;
            this.사상.UseVisualStyleBackColor = true;
            this.사상.CheckedChanged += new System.EventHandler(this.사상_CheckedChanged);
            // 
            // 감천
            // 
            this.감천.AutoSize = true;
            this.감천.Location = new System.Drawing.Point(460, 142);
            this.감천.Name = "감천";
            this.감천.Size = new System.Drawing.Size(14, 13);
            this.감천.TabIndex = 10;
            this.감천.TabStop = true;
            this.감천.UseVisualStyleBackColor = true;
            this.감천.CheckedChanged += new System.EventHandler(this.감천_CheckedChanged);
            // 
            // 동의대
            // 
            this.동의대.AutoSize = true;
            this.동의대.Location = new System.Drawing.Point(397, 142);
            this.동의대.Name = "동의대";
            this.동의대.Size = new System.Drawing.Size(14, 13);
            this.동의대.TabIndex = 9;
            this.동의대.TabStop = true;
            this.동의대.UseVisualStyleBackColor = true;
            this.동의대.CheckedChanged += new System.EventHandler(this.동의대_CheckedChanged);
            // 
            // 서면
            // 
            this.서면.AutoSize = true;
            this.서면.Location = new System.Drawing.Point(337, 142);
            this.서면.Name = "서면";
            this.서면.Size = new System.Drawing.Size(14, 13);
            this.서면.TabIndex = 8;
            this.서면.TabStop = true;
            this.서면.UseVisualStyleBackColor = true;
            this.서면.CheckedChanged += new System.EventHandler(this.서면_CheckedChanged);
            // 
            // 부산은행
            // 
            this.부산은행.AutoSize = true;
            this.부산은행.Location = new System.Drawing.Point(297, 142);
            this.부산은행.Name = "부산은행";
            this.부산은행.Size = new System.Drawing.Size(14, 13);
            this.부산은행.TabIndex = 7;
            this.부산은행.TabStop = true;
            this.부산은행.UseVisualStyleBackColor = true;
            this.부산은행.CheckedChanged += new System.EventHandler(this.부산은행_CheckedChanged);
            // 
            // 경성대
            // 
            this.경성대.AutoSize = true;
            this.경성대.Location = new System.Drawing.Point(210, 142);
            this.경성대.Name = "경성대";
            this.경성대.Size = new System.Drawing.Size(14, 13);
            this.경성대.TabIndex = 6;
            this.경성대.TabStop = true;
            this.경성대.UseVisualStyleBackColor = true;
            this.경성대.CheckedChanged += new System.EventHandler(this.경성대_CheckedChanged);
            // 
            // 광안
            // 
            this.광안.AutoSize = true;
            this.광안.Location = new System.Drawing.Point(158, 142);
            this.광안.Name = "광안";
            this.광안.Size = new System.Drawing.Size(14, 13);
            this.광안.TabIndex = 5;
            this.광안.TabStop = true;
            this.광안.UseVisualStyleBackColor = true;
            this.광안.CheckedChanged += new System.EventHandler(this.광안_CheckedChanged);
            // 
            // 수영
            // 
            this.수영.AutoSize = true;
            this.수영.Location = new System.Drawing.Point(138, 142);
            this.수영.Name = "수영";
            this.수영.Size = new System.Drawing.Size(14, 13);
            this.수영.TabIndex = 4;
            this.수영.TabStop = true;
            this.수영.UseVisualStyleBackColor = true;
            this.수영.CheckedChanged += new System.EventHandler(this.수영_CheckedChanged);
            // 
            // 센텀시티
            // 
            this.센텀시티.AutoSize = true;
            this.센텀시티.Location = new System.Drawing.Point(103, 142);
            this.센텀시티.Name = "센텀시티";
            this.센텀시티.Size = new System.Drawing.Size(14, 13);
            this.센텀시티.TabIndex = 3;
            this.센텀시티.TabStop = true;
            this.센텀시티.UseVisualStyleBackColor = true;
            this.센텀시티.CheckedChanged += new System.EventHandler(this.센텀시티_CheckedChanged);
            // 
            // 시립미술관
            // 
            this.시립미술관.AutoSize = true;
            this.시립미술관.Location = new System.Drawing.Point(83, 142);
            this.시립미술관.Name = "시립미술관";
            this.시립미술관.Size = new System.Drawing.Size(14, 13);
            this.시립미술관.TabIndex = 2;
            this.시립미술관.TabStop = true;
            this.시립미술관.UseVisualStyleBackColor = true;
            this.시립미술관.CheckedChanged += new System.EventHandler(this.시립미술관_CheckedChanged);
            // 
            // 해운대
            // 
            this.해운대.AutoSize = true;
            this.해운대.Location = new System.Drawing.Point(49, 142);
            this.해운대.Name = "해운대";
            this.해운대.Size = new System.Drawing.Size(14, 13);
            this.해운대.TabIndex = 1;
            this.해운대.TabStop = true;
            this.해운대.UseVisualStyleBackColor = true;
            this.해운대.CheckedChanged += new System.EventHandler(this.해운대_CheckedChanged);
            // 
            // 장산
            // 
            this.장산.AutoSize = true;
            this.장산.Location = new System.Drawing.Point(18, 142);
            this.장산.Name = "장산";
            this.장산.Size = new System.Drawing.Size(14, 13);
            this.장산.TabIndex = 0;
            this.장산.TabStop = true;
            this.장산.UseVisualStyleBackColor = true;
            this.장산.CheckedChanged += new System.EventHandler(this.장산_CheckedChanged);
            // 
            // _2호선
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 366);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "_2호선";
            this.Text = "_2호선";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton 장산;
        private System.Windows.Forms.RadioButton 서면;
        private System.Windows.Forms.RadioButton 부산은행;
        private System.Windows.Forms.RadioButton 경성대;
        private System.Windows.Forms.RadioButton 광안;
        private System.Windows.Forms.RadioButton 수영;
        private System.Windows.Forms.RadioButton 센텀시티;
        private System.Windows.Forms.RadioButton 시립미술관;
        private System.Windows.Forms.RadioButton 해운대;
        private System.Windows.Forms.RadioButton 양산;
        private System.Windows.Forms.RadioButton 부산대양산;
        private System.Windows.Forms.RadioButton 덕천;
        private System.Windows.Forms.RadioButton 사상;
        private System.Windows.Forms.RadioButton 감천;
        private System.Windows.Forms.RadioButton 동의대;
    }
}