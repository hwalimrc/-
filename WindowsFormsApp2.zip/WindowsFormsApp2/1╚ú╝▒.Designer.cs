﻿namespace WindowsFormsApp2
{
    partial class _1호선
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(_1호선));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.동래 = new System.Windows.Forms.RadioButton();
            this.노포동 = new System.Windows.Forms.RadioButton();
            this.부산대 = new System.Windows.Forms.RadioButton();
            this.교대앞 = new System.Windows.Forms.RadioButton();
            this.연산동 = new System.Windows.Forms.RadioButton();
            this.시청 = new System.Windows.Forms.RadioButton();
            this.서면 = new System.Windows.Forms.RadioButton();
            this.범내골 = new System.Windows.Forms.RadioButton();
            this.부산역 = new System.Windows.Forms.RadioButton();
            this.중앙동 = new System.Windows.Forms.RadioButton();
            this.남포동 = new System.Windows.Forms.RadioButton();
            this.자갈치 = new System.Windows.Forms.RadioButton();
            this.부산대병원 = new System.Windows.Forms.RadioButton();
            this.사하 = new System.Windows.Forms.RadioButton();
            this.당리 = new System.Windows.Forms.RadioButton();
            this.하단 = new System.Windows.Forms.RadioButton();
            this.신봉 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(16, 324);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "역 이름을 선택하세요:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(284, 327);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 21);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "역 이름을 선택하세요";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(342, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 30);
            this.button1.TabIndex = 3;
            this.button1.Text = "출발역으로 지정";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(544, 378);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(181, 30);
            this.button2.TabIndex = 4;
            this.button2.Text = "도착역으로 지정";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::WindowsFormsApp2.Properties.Resources._1호선1;
            this.panel1.Controls.Add(this.동래);
            this.panel1.Controls.Add(this.노포동);
            this.panel1.Controls.Add(this.부산대);
            this.panel1.Controls.Add(this.교대앞);
            this.panel1.Controls.Add(this.연산동);
            this.panel1.Controls.Add(this.시청);
            this.panel1.Controls.Add(this.서면);
            this.panel1.Controls.Add(this.범내골);
            this.panel1.Controls.Add(this.부산역);
            this.panel1.Controls.Add(this.중앙동);
            this.panel1.Controls.Add(this.남포동);
            this.panel1.Controls.Add(this.자갈치);
            this.panel1.Controls.Add(this.부산대병원);
            this.panel1.Controls.Add(this.사하);
            this.panel1.Controls.Add(this.당리);
            this.panel1.Controls.Add(this.하단);
            this.panel1.Controls.Add(this.신봉);
            this.panel1.Location = new System.Drawing.Point(13, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(705, 303);
            this.panel1.TabIndex = 0;
            // 
            // 동래
            // 
            this.동래.AutoSize = true;
            this.동래.Location = new System.Drawing.Point(364, 70);
            this.동래.Name = "동래";
            this.동래.Size = new System.Drawing.Size(14, 13);
            this.동래.TabIndex = 16;
            this.동래.TabStop = true;
            this.동래.UseVisualStyleBackColor = true;
            this.동래.CheckedChanged += new System.EventHandler(this.동래_CheckedChanged);
            // 
            // 노포동
            // 
            this.노포동.AutoSize = true;
            this.노포동.Location = new System.Drawing.Point(34, 70);
            this.노포동.Name = "노포동";
            this.노포동.Size = new System.Drawing.Size(14, 13);
            this.노포동.TabIndex = 15;
            this.노포동.TabStop = true;
            this.노포동.UseVisualStyleBackColor = true;
            this.노포동.CheckedChanged += new System.EventHandler(this.노포동_CheckedChanged);
            // 
            // 부산대
            // 
            this.부산대.AutoSize = true;
            this.부산대.Location = new System.Drawing.Point(253, 70);
            this.부산대.Name = "부산대";
            this.부산대.Size = new System.Drawing.Size(14, 13);
            this.부산대.TabIndex = 14;
            this.부산대.TabStop = true;
            this.부산대.UseVisualStyleBackColor = true;
            this.부산대.CheckedChanged += new System.EventHandler(this.부산대_CheckedChanged);
            // 
            // 교대앞
            // 
            this.교대앞.AutoSize = true;
            this.교대앞.Location = new System.Drawing.Point(401, 70);
            this.교대앞.Name = "교대앞";
            this.교대앞.Size = new System.Drawing.Size(14, 13);
            this.교대앞.TabIndex = 13;
            this.교대앞.TabStop = true;
            this.교대앞.UseVisualStyleBackColor = true;
            this.교대앞.CheckedChanged += new System.EventHandler(this.교대앞_CheckedChanged);
            // 
            // 연산동
            // 
            this.연산동.AutoSize = true;
            this.연산동.Location = new System.Drawing.Point(439, 70);
            this.연산동.Name = "연산동";
            this.연산동.Size = new System.Drawing.Size(14, 13);
            this.연산동.TabIndex = 12;
            this.연산동.TabStop = true;
            this.연산동.UseVisualStyleBackColor = true;
            this.연산동.CheckedChanged += new System.EventHandler(this.연산동_CheckedChanged);
            // 
            // 시청
            // 
            this.시청.AutoSize = true;
            this.시청.Location = new System.Drawing.Point(474, 70);
            this.시청.Name = "시청";
            this.시청.Size = new System.Drawing.Size(14, 13);
            this.시청.TabIndex = 11;
            this.시청.TabStop = true;
            this.시청.UseVisualStyleBackColor = true;
            this.시청.CheckedChanged += new System.EventHandler(this.시청_CheckedChanged);
            // 
            // 서면
            // 
            this.서면.AutoSize = true;
            this.서면.Location = new System.Drawing.Point(585, 88);
            this.서면.Name = "서면";
            this.서면.Size = new System.Drawing.Size(14, 13);
            this.서면.TabIndex = 10;
            this.서면.TabStop = true;
            this.서면.UseVisualStyleBackColor = true;
            this.서면.CheckedChanged += new System.EventHandler(this.서면_CheckedChanged);
            // 
            // 범내골
            // 
            this.범내골.AutoSize = true;
            this.범내골.Location = new System.Drawing.Point(585, 124);
            this.범내골.Name = "범내골";
            this.범내골.Size = new System.Drawing.Size(14, 13);
            this.범내골.TabIndex = 9;
            this.범내골.TabStop = true;
            this.범내골.UseVisualStyleBackColor = true;
            this.범내골.CheckedChanged += new System.EventHandler(this.범내골_CheckedChanged);
            // 
            // 부산역
            // 
            this.부산역.AutoSize = true;
            this.부산역.Location = new System.Drawing.Point(474, 212);
            this.부산역.Name = "부산역";
            this.부산역.Size = new System.Drawing.Size(14, 13);
            this.부산역.TabIndex = 8;
            this.부산역.TabStop = true;
            this.부산역.UseVisualStyleBackColor = true;
            this.부산역.CheckedChanged += new System.EventHandler(this.부산역_CheckedChanged);
            // 
            // 중앙동
            // 
            this.중앙동.AutoSize = true;
            this.중앙동.Location = new System.Drawing.Point(439, 212);
            this.중앙동.Name = "중앙동";
            this.중앙동.Size = new System.Drawing.Size(14, 13);
            this.중앙동.TabIndex = 7;
            this.중앙동.TabStop = true;
            this.중앙동.UseVisualStyleBackColor = true;
            this.중앙동.CheckedChanged += new System.EventHandler(this.중앙동_CheckedChanged);
            // 
            // 남포동
            // 
            this.남포동.AutoSize = true;
            this.남포동.Location = new System.Drawing.Point(401, 212);
            this.남포동.Name = "남포동";
            this.남포동.Size = new System.Drawing.Size(14, 13);
            this.남포동.TabIndex = 6;
            this.남포동.TabStop = true;
            this.남포동.UseVisualStyleBackColor = true;
            this.남포동.CheckedChanged += new System.EventHandler(this.남포동_CheckedChanged);
            // 
            // 자갈치
            // 
            this.자갈치.AutoSize = true;
            this.자갈치.Location = new System.Drawing.Point(364, 212);
            this.자갈치.Name = "자갈치";
            this.자갈치.Size = new System.Drawing.Size(14, 13);
            this.자갈치.TabIndex = 5;
            this.자갈치.TabStop = true;
            this.자갈치.UseVisualStyleBackColor = true;
            this.자갈치.CheckedChanged += new System.EventHandler(this.자갈치_CheckedChanged);
            // 
            // 부산대병원
            // 
            this.부산대병원.AutoSize = true;
            this.부산대병원.Location = new System.Drawing.Point(329, 212);
            this.부산대병원.Name = "부산대병원";
            this.부산대병원.Size = new System.Drawing.Size(14, 13);
            this.부산대병원.TabIndex = 4;
            this.부산대병원.TabStop = true;
            this.부산대병원.UseVisualStyleBackColor = true;
            this.부산대병원.CheckedChanged += new System.EventHandler(this.부산대병원_CheckedChanged);
            // 
            // 사하
            // 
            this.사하.AutoSize = true;
            this.사하.Location = new System.Drawing.Point(146, 212);
            this.사하.Name = "사하";
            this.사하.Size = new System.Drawing.Size(14, 13);
            this.사하.TabIndex = 3;
            this.사하.TabStop = true;
            this.사하.UseVisualStyleBackColor = true;
            this.사하.CheckedChanged += new System.EventHandler(this.사하_CheckedChanged);
            // 
            // 당리
            // 
            this.당리.AutoSize = true;
            this.당리.Location = new System.Drawing.Point(107, 212);
            this.당리.Name = "당리";
            this.당리.Size = new System.Drawing.Size(14, 13);
            this.당리.TabIndex = 2;
            this.당리.TabStop = true;
            this.당리.UseVisualStyleBackColor = true;
            this.당리.CheckedChanged += new System.EventHandler(this.당리_CheckedChanged);
            // 
            // 하단
            // 
            this.하단.AutoSize = true;
            this.하단.Location = new System.Drawing.Point(72, 212);
            this.하단.Name = "하단";
            this.하단.Size = new System.Drawing.Size(14, 13);
            this.하단.TabIndex = 1;
            this.하단.TabStop = true;
            this.하단.UseVisualStyleBackColor = true;
            this.하단.CheckedChanged += new System.EventHandler(this.하단_CheckedChanged);
            // 
            // 신봉
            // 
            this.신봉.AutoSize = true;
            this.신봉.Location = new System.Drawing.Point(34, 212);
            this.신봉.Name = "신봉";
            this.신봉.Size = new System.Drawing.Size(14, 13);
            this.신봉.TabIndex = 0;
            this.신봉.TabStop = true;
            this.신봉.UseVisualStyleBackColor = true;
            this.신봉.CheckedChanged += new System.EventHandler(this.신봉_CheckedChanged);
            // 
            // _1호선
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 420);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "_1호선";
            this.Text = "1호선";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RadioButton 신봉;
        private System.Windows.Forms.RadioButton 노포동;
        private System.Windows.Forms.RadioButton 부산대;
        private System.Windows.Forms.RadioButton 교대앞;
        private System.Windows.Forms.RadioButton 연산동;
        private System.Windows.Forms.RadioButton 시청;
        private System.Windows.Forms.RadioButton 서면;
        private System.Windows.Forms.RadioButton 범내골;
        private System.Windows.Forms.RadioButton 부산역;
        private System.Windows.Forms.RadioButton 중앙동;
        private System.Windows.Forms.RadioButton 남포동;
        private System.Windows.Forms.RadioButton 자갈치;
        private System.Windows.Forms.RadioButton 부산대병원;
        private System.Windows.Forms.RadioButton 사하;
        private System.Windows.Forms.RadioButton 당리;
        private System.Windows.Forms.RadioButton 하단;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton 동래;
    }
}